# Results

| Analysis | Files |
| --- | --- |
| Calibration | [Grid](calibration_grid.csv), [leaf-level grid](calibration_leaf_grid.csv), [frozen config](frozen_config.json), [plant split](split.csv) |
| Symptom detection | [Held-out metrics](detection.csv), [audit of high-scoring N leaves](audit_top_N_leaves.csv) |
| Symptom progression | [Mixed model](progression_mixed_model.csv), [per-plant trends](progression_per_plant.csv), [plant-day summaries](progression_plant_days.csv), [trend summary](progression_summary.csv) |
| Synthetic lesion area and placement | [Agreement](known_severity/agreement.csv), [placement recovery](known_severity/placement_recovery.csv), [per-overlay scores](known_severity/known_severity_leaves.csv) |
| Tip burn vs. yellowing | [Metrics](discrimination.csv), [by treatment](discrimination_by_treatment.csv), [out-of-fold predictions](discrimination_oof_predictions.csv), [coefficients](discrimination_coefficients.csv), [placement means](discrimination_placement_means.csv) |
| Exploratory nitrogen vs. iron deficiency within yellowing | [Metrics](exploratory_N_vs_Fe.csv), [out-of-fold predictions](exploratory_N_vs_Fe_oof_predictions.csv) |

The detection table uses held-out plants. The symptom-category comparisons use plant-grouped cross-validation and report leaf and plant results separately. The audit omits machine-local image paths.
